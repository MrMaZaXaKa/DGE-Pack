# DGE Test Resource Pack

Тестовый ресурс-пак для пиксельных бейджей в TAB. Содержит бейджи: Легендарный, Игрок, Админ, Доверенный и Ветеран.

## Проверка через GitHub

1. Создай публичный GitHub-репозиторий.
2. Загрузи `DGE-Test-Pack.zip` в корень репозитория.
3. Получи прямую ссылку вида:

```text
https://raw.githubusercontent.com/<твой-логин>/<репозиторий>/main/DGE-Test-Pack.zip
```

4. В `server.properties` укажи:

```properties
resource-pack=<прямая ссылка на zip>
require-resource-pack=false
resource-pack-prompt={"text":"Для пиксельных бейджей TAB нужен DGE Test Pack"}
```

5. Перезапусти сервер и прими пакет при входе.
6. После проверки скопируй нужные блоки из `TAB-groups-with-pack.yml` в `plugins/TAB/groups.yml` и перезапусти сервер ещё раз.

Для строгой проверки можно добавить SHA-1 пакета в `resource-pack-sha1`.
